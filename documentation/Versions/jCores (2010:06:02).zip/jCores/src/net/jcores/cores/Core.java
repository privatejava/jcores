/*
 * Core.java
 * 
 * Copyright (c) 2010, Ralf Biedert All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, are
 * permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer. Redistributions in binary form must reproduce the
 * above copyright notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of the author nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package net.jcores.cores;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import net.jcores.CommonCore;
import net.jcores.interfaces.functions.F1;
import net.jcores.options.Option;

/**
 * @author rb
 *
 * @param <T>
 */
public class Core<T> {

    /** The array we work on (if no fallback was provided) */
    final T[] t;

    /** Fallback collection if no array was provided. */
    final Collection<T> t$;

    /** Our parent */
    final CommonCore commonCore;

    /**
     * Creates the core object for the given collection.
     * 
     * @param core 
     * @param collection 
     * @param t
     */
    @SuppressWarnings("unchecked")
    public Core(CommonCore core, Collection<T> collection, T... t) {
        this.t = t;
        this.t$ = collection;
        this.commonCore = core;

        // Check that we are properly called
        assert !(t.length > 0 && collection != null) : "Severe error. We must have only one!";
    }

    /**
     * Returns the wrapped collection as a list
     * 
     * @return .
     */
    public List<T> list() {
        // TODO: Recognize colletion
        return Arrays.asList(this.t);
    }

    /**
     * Return our content as an array.
     * 
     * @return .
     */
    public T[] array() {
        // TODO: Recognize colletion
        return this.t;
    }

    /**
     * Return our content as an array.
     * @param in 
     * @param <N> 
     * 
     * @return .
     */
    @SuppressWarnings("unchecked")
    public <N> N[] array(N[] in) {
        // TODO: Recognize colletion        
        return (N[]) Arrays.copyOf(this.t, this.t.length, in.getClass());
    }

    /**
     * Returns how many items are in this core. 
     * 
     * @return .
     */
    public int size() {
        // TODO: Recognize colletion        
        return this.t.length;
    }

    /**
     * Returns the first element, or, if there is none, return dflt.
     * 
     * @param dflt
     * @return .
     */
    public T get(T dflt) {
        // TODO: Recognize colletion        
        return null;
    }

    /**
     * Return the ith element.
     * 
     * @param i
     * 
     * @return .
     */
    public T get(int i) {
        // TODO: Recognize colletion    
        if (i >= this.t.length) return null;

        return this.t[i];
    }

    /**
     * Maps the core's content with the given function and returns the result.
     * 
     * @param <R> 
     * @param f
     * @param options 
     * 
     * @return The mapped elements in a stable order   
     */
    @SuppressWarnings("unchecked")
    public <R> Core<R> map(final F1<T, R> f, Option... options) {
        // TODO: Recognize colletion        

        final int STEP_SIZE = 3000;
        final int NUM_THREADS = 2;

        final int size = size();

        // TODO: Check size, if small, don't do all this setup in here ...

        // According to the Java internals Arrays.toList() must be the fastest way
        // to create a List, so handle the proper array creation in here
        // However, we have to use a trick to get the type of R ... (thanks type erasure!)
        final AtomicReference<R[]> r = new AtomicReference<R[]>();
        final AtomicInteger baseCount = new AtomicInteger();

        final CyclicBarrier barrier = new CyclicBarrier(NUM_THREADS + 1);

        final Runnable runner = new Runnable() {
            public void run() {
                final T[] local = Core.this.t;
                R[] array = r.get();

                int lower = baseCount.getAndIncrement() * STEP_SIZE;

                // Get new basecount for every pass ...
                while (lower < size) {
                    
                    final int max = Math.min(lower+STEP_SIZE, size);
                    
                    // Pass over all elements
                    for (int i = lower; i < max; i++) {
                        final T in = local[i];

                        // Handle element and check for null
                        if (in == null) continue;
                        final R out = f.f(in);
                        if (out == null) continue;

                        // In case our array is null (this should happen only very infrequently) ... 
                        if (array == null) {
                            array = (R[]) Array.newInstance(out.getClass(), size);
                            r.compareAndSet(null, array);
                            array = r.get();
                        }

                        array[i] = out;
                    }

                    lower = baseCount.getAndIncrement() * STEP_SIZE;
                }

                // Signal finish
                try {
                    barrier.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (BrokenBarrierException e) {
                    e.printStackTrace();
                }
            }
        };

        this.commonCore.execute(runner, NUM_THREADS);

        // Wait for all threads to finish ...
        try {
            barrier.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (BrokenBarrierException e) {
            e.printStackTrace();
        }

        // Return our results
        return new Core<R>(this.commonCore, null, r.get());
    }

    /**
     * Filters the object using the given function. 
     * 
     * @param f If f returns true the object is kept. 
     * @param options
     * 
     * @return . 
     */
    @SuppressWarnings("boxing")
    public Core<T> filter(F1<T, Boolean> f, Option... options) {
        // TODO: Recognize colletion        

        final ArrayList<T> rval = new ArrayList<T>(size());

        for (T x : this.t) {
            if (f.f(x)) rval.add(x);
        }

        return new Core<T>(this.commonCore, rval);
    }
}
