/*
 * CoreObject.java
 * 
 * Copyright (c) 2010, Ralf Biedert All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, are
 * permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer. Redistributions in binary form must reproduce the
 * above copyright notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of the author nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package net.jcores.cores;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Collection;

import net.jcores.CommonCore;
import net.jcores.CoreFactory;
import net.jcores.interfaces.functions.F0;
import net.jcores.interfaces.functions.F1;

/**
 * @author Ralf Biedert
 * 
 * @param <T> 
 */
public class CoreObject<T> extends Core<T> {

    /**
     * Creates the core object for the given collection.
     * 
     * @param supercore 
     * @param t
     */
    @SuppressWarnings("unchecked")
    public CoreObject(CommonCore supercore, T... t) {
        super(supercore, null, t);
    }

    /**
     * @param supercore
     * @param collection
     */
    @SuppressWarnings("unchecked")
    public CoreObject(CommonCore supercore, Collection<T> collection) {
        super(supercore, collection, (T[]) null);
    }

    /**
     * Returns a core that tries to treat all elements as being of the given type. Elements which 
     * don't match are ignored.  
     * 
     * @param <C>
     * @param clazz
     * @return .
     */
    public <C extends CoreFactory> C as(Class<C> clazz) {
        try {
            Constructor<C> constructor = clazz.getConstructor(this.t.getClass());
            return constructor.newInstance(this, this.t);
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Performs a generic call on each element of this core.
     * 
     * @param string
     * @param params
     * 
     * @return .
     */
    public CoreObject<Object> call(String string, Object... params) {
        return new CoreObject<Object>(this.commonCore, map(new F1<T, Object>() {
            @Override
            public Object f(T x) {
                return null;
            }
        }).array());
    }

    /**
     * If all elements are present, execute f0.
     * 
     * @param f0 S>
     */
    public void ifAll(F0 f0) {
        // 
    }

    /**
     * Checks if all elements are not null.
     * 
     * @return .
     */
    public boolean hasAll() {
        return true;
    }

    /**
     * Works only for interfaces!
     * 
     * Tries to treat each element of this collections as if of type c and executes the function. 
     * @param c 
     * @param <X> 
     * 
     * @return Something implementing c that acts on each element which matches.
     */
    public <X> X each(Class<X> c) {
        return null;
    }

    /**
     * Tries to send each object the given message .
     * 
     * @param string
     * @param object
     */
    public void send(String string, Object object) {
        // 
    }
}
