/*
 * CoreObject.java
 * 
 * Copyright (c) 2010, Ralf Biedert All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, are
 * permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer. Redistributions in binary form must reproduce the
 * above copyright notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of the author nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package net.jcores.cores;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;

import net.jcores.CommonCore;
import net.jcores.CoreFactory;
import net.jcores.interfaces.functions.F0;
import net.jcores.interfaces.functions.F1;
import net.jcores.interfaces.functions.F1Object2Bool;
import net.jcores.interfaces.functions.F1Object2Int;
import net.jcores.interfaces.functions.F2ReduceObjects;
import net.jcores.options.Option;
import net.jcores.util.Mapper;

/**
 * @author Ralf Biedert
 * 
 * @param <T> 
 */
public class CoreObject<T> extends Core {

    /** The array we work on (if no fallback was provided) */
    final T[] t;

    /**
     * Creates the core object for the given collection.
     * 
     * @param supercore 
     * @param t
     */
    public CoreObject(CommonCore supercore, T... t) {
        super(supercore);

        this.t = t;
    }

    /**
     * Returns a core that tries to treat all elements as being of the given type. Elements which 
     * don't match are ignored.  
     * 
     * TODO: Check if this method is sound ...
     * 
     * @param <C>
     * @param clazz
     * @return .
     */
    @Deprecated
    public <C extends CoreFactory> C as(Class<C> clazz) {
        try {
            Constructor<C> constructor = clazz.getConstructor(this.t.getClass());
            return constructor.newInstance(this, this.t);
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Performs a generic call on each element of this core.
     * 
     * @param string
     * @param params
     * 
     * @return .
     */
    public CoreObject<Object> call(String string, Object... params) {
        return new CoreObject<Object>(this.commonCore, map(new F1<T, Object>() {
            @Override
            public Object f(T x) {
                return null;
            }
        }).array());
    }

    /**
     * If all elements are present, execute f0.
     * 
     * @param f0 S>
     */
    public void ifAll(F0 f0) {
        if (hasAll()) f0.f();
    }

    /**
     * Checks if all elements are not null.
     * 
     * @return .
     */
    public boolean hasAll() {
        return size() == compact().size();
    }

    /**
     * Checks if the element has any element.
     * 
     * @return .
     */
    public boolean hasAny() {
        return compact().size() > 0;
    }

    /**
     * Works only for interfaces!
     * 
     * Tries to treat each element of this collections as if of type c and executes the function. 
     * @param c 
     * @param <X> 
     * 
     * @return Something implementing c that acts on each element which matches.
     */
    public <X> X each(Class<X> c) {
        return null;
    }

    /**
     * Tries to send each object the given message .
     * 
     * @param string
     * @param object
     */
    public void send(String string, Object object) {
        // 
    }

    /**
     * Returns the wrapped collection as a list
     * 
     * @return .
     */
    public List<T> list() {
        return Arrays.asList(this.t);
    }

    /**
     * Return our content as an array.
     * 
     * @return .
     */
    public T[] array() {
        return this.t;
    }

    /**
     * Return our content as an array.
     * @param in 
     * @param <N> 
     * 
     * @return .
     */
    @SuppressWarnings("unchecked")
    public <N> N[] array(N[] in) {
        return (N[]) Arrays.copyOf(this.t, this.t.length, in.getClass());
    }

    /**
     * Returns how many items are in this core. 
     * 
     * @return .
     */
    @Override
    public int size() {
        return this.t.length;
    }

    /**
     * Returns the first element, or, if there is none, return dflt.
     * 
     * @param dflt
     * @return .
     */
    public T get(T dflt) {
        // TODO: Recognize colletion        
        return null;
    }

    /**
     * Return the ith element.
     * 
     * @param i
     * 
     * @return .
     */
    public T get(int i) {
        // TODO: Recognize colletion    
        if (i >= this.t.length) return null;

        return this.t[i];
    }

    /**
     * Maps the core's content with the given function and returns the result.
     * 
     * @param <R> 
     * @param f
     * @param options 
     * 
     * @return The mapped elements in a stable order   
     */
    @SuppressWarnings("unchecked")
    public <R> CoreObject<R> map(final F1<T, R> f, Option... options) {
        final Mapper mapper = new Mapper(this.t.length) {
            @Override
            public void handle(int i) {
                R[] a = (R[]) this.array.get();

                final T in = CoreObject.this.t[i];

                if (in == null) return;
                final R out = f.f(in);
                if (out == null) return;

                if (a == null) {
                    a = (R[]) updateArray(Array.newInstance(out.getClass(), this.size));
                }

                a[i] = out;
            }
        };

        map(mapper, options);

        return new CoreObject(this.commonCore, (R[]) mapper.getTargetArray());
    }

    /**
     * Maps the core's content with the given function and returns the result.
     * 
     * @param f
     * @param options 
     * 
     * @return The mapped elements in a stable order   
     */
    public CoreInt map(final F1Object2Int<T> f, Option... options) {
        final Mapper mapper = new Mapper(int.class, this.t.length) {
            @Override
            public void handle(int i) {
                int[] a = (int[]) this.array.get();
                a[i] = f.f(CoreObject.this.t[i]);
            }
        };

        map(mapper, options);

        return new CoreInt(this.commonCore, (int[]) mapper.getTargetArray());
    }

    /**
     * Filters the object using the given function. A compacted array will be returned that
     * contains only values for which f returned true.
     * 
     * @param f If f returns true the object is kept. 
     * @param options
     * 
     * @return . 
     */
    public CoreObject<T> filter(final F1Object2Bool<T> f, Option... options) {
        CoreObject<T> rval = map(new F1<T, T>() {
            public T f(T x) {
                if (f.f(x)) return x;
                return null;
            }
        });

        return rval.compact();
    }

    /**
     * Reduces the given object.
     * 
     * @param f
     * @param options
     * @return .
     */
    public CoreObject<T> reduce(final F2ReduceObjects<T> f, Option... options) {
        T stack = null;
        
        return new CoreObject<T>(this.commonCore, (T[]) stack);
    }

    /**
     * Returns a compacted object whose underlaying array does not 
     * contain null anymore .
     * 
     * @return . 
     */
    public CoreObject<T> compact() {
        final T[] tmp = Arrays.copyOf(this.t, this.t.length);
        int dst = 0;

        // Now process our array
        for (int i = 0; i < this.t.length; i++) {
            if (this.t[i] == null) continue;

            tmp[dst++] = this.t[i];
        }

        return new CoreObject<T>(this.commonCore, Arrays.copyOf(tmp, dst));
    }
}
