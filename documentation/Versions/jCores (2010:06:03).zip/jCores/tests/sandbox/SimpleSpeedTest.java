/*
 * SimpleSpeedTests.java
 * 
 * Copyright (c) 2010, Ralf Biedert All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, are
 * permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer. Redistributions in binary form must reproduce the
 * above copyright notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of the author nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package sandbox;

import static net.jcores.CoreFactory.$;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import net.jcores.interfaces.functions.F0;
import net.jcores.interfaces.functions.F1;
import net.jcores.interfaces.functions.F1Int2Int;

/**
 * @author rb
 *
 */
public class SimpleSpeedTest {
    /**
     * @param args
     */
    public static void main(String[] args) {
        int size = 1000000;
        final String strings[] = constructStrings(size);
        final int[] ints = constructInts(size);
        final long[] longs = constructLongs(size);

        final int[] res = new int[size];
        final long[] resl = new long[size];

      
        System.out.println();

        
        long b1 = benchmark(new F0() {
            public void f() {
                $(strings).map(new F1<String, String>() {
                    public String f(String x) {
                        return x.toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase();
                        //return x.toLowerCase();
                    }
                });
            }
        }, 10);

        System.out.println();
        
        
        /*
         * Removed, the ___map was the first version of map without the mapper, was ~10-20% faster but only
         * when F1 was very lightweight. For heavyweight cases of F1 no significant difference was noticable.
        long b11 = benchmark(new F0() {
            public void f() {
                $(strings).____map(new F1<String, String>() {
                    public String f(String x) {
                        return x.toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase();
                        //return x.toLowerCase();
                    }
                });
            }
        }, 10);
         */
        
        System.out.println();

        long b2 = benchmark(new F0() {
            public void f() {
                for (int i = 0; i < strings.length; i++) {
                    strings[i] = strings[i].toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase().toLowerCase();
                    //strings[i] = strings[i].toLowerCase();
                }
            }
        }, 10);

        
        System.out.println();

        long b3 = benchmark(new F0() {
            public void f() {
                $(ints).map(new F1Int2Int() {
                    public int f(int x) {
                        return (int) Math.sqrt(Math.tan(x * x));
                    }
                });
            }
        }, 10);

        System.out.println();

        long b4 = benchmark(new F0() {
            public void f() {
                for (int i = 0; i < ints.length; i++) {
                    int x = ints[i];
                    res[i] = (int) Math.sqrt(Math.tan(x * x));
                }
            }
        }, 10);
        

        System.out.println();

        long b6 = benchmark(new F0() {
            public void f() {
                for (int i = 0; i < longs.length; i++) {
                    resl[i] = longs[i] * longs[i];
                }
            }
        }, 10);

        System.out.println();
        System.out.println(b1);
        System.out.println(b2);
        System.out.println(b3);
        System.out.println(b4);
        System.out.println(b6);
    }

    private static String[] constructStrings(int size) {
        final List<String> l = new ArrayList<String>();
        final Random r = new Random();

        for (int i = 0; i < size; i++) {
            l.add("" + r.nextInt());
        }

        return l.toArray(new String[0]);
    }

    private static int[] constructInts(int size) {
        int[] l = new int[size];
        final Random r = new Random();

        for (int i = 0; i < size; i++) {
            l[i] = r.nextInt();
        }

        return l;
    }

    private static long[] constructLongs(int size) {
        long[] l = new long[size];
        final Random r = new Random();

        for (int i = 0; i < size; i++) {
            l[i] = r.nextLong();
        }

        return l;
    }
    
    
    /**
     * Executes f and returns the time taken.
     * 
     * @param f
     * @return .
     */
    public static long benchmark(F0 f) {
        long start = System.nanoTime();
        f.f();
        long stop = System.nanoTime();
        return (stop - start) / 1000;
    }

    /**
     * @param f
     * @param passes
     * @return .
     */
    public static long benchmark(F0 f, int passes) {
        long results[] = new long[passes];

        for (int i = 0; i < results.length; i++) {
            results[i] = benchmark(f);
            System.out.println(results[i]);
        }

        long avg = 0;

        for (int i = 1; i < results.length; i++) {
            avg += results[i];
        }

        avg /= passes - 1;

        return avg;
    }

}
