/*
 * API.java
 * 
 * Copyright (c) 2010, Ralf Biedert All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, are
 * permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this list of
 * conditions and the following disclaimer. Redistributions in binary form must reproduce the
 * above copyright notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 
 * Neither the name of the author nor the names of its contributors may be used to endorse or
 * promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package sandbox;

import static net.jcores.CoreFactory.$;
import net.jcores.interfaces.functions.F1Int2Int;
import net.jcores.interfaces.functions.F1Int2Object;
import net.jcores.interfaces.functions.F1Object2Int;

/**
 * @author rb
 */
public class APIv3 {
    /**
     * @param args
     */
    public static void main(String[] args) {
        String[] split = "ajslkd,a asj dlasd ad aosidasoidua sdiuza odiuazs odiuasz doiuasz oiasz oisazdoidzizdzzd zd zd dzd".split(" ");
        String s = $(split).map(new F1Object2Int<String>() {
            public int f(String i) {
                return i.length();
            }
        }).map(new F1Int2Int() {
            public int f(int i) {
                return i * i;
            }
        }).map(new F1Int2Object<Integer>() {
            public Integer f(int i) {
                return Integer.valueOf(i - 1);
            }
        }).get(0).getClass().getCanonicalName();
        System.out.println(s);
        
        int size = $("hello", null, "world").compact().size();
        System.out.println(size);
        
        System.out.println($("hello", "you", "world", null).hasAll());
        
        $("Hello world").log();
    }
}
